import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void mainMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Travella TicTacToe!");

        // Instantiate an object of game class:
        Game game = new Game();

        // Instantiate an object of player class:
        Player player = new Player();

        System.out.println("Please enter your name: ");
        String firstPlayer = scanner.nextLine();
        player.setFirstPlayer(firstPlayer);

        System.out.println("Enter 1 to play against AI \nEnter 2 to play against human");
        int counterPlayer = scanner.nextInt();

        if (counterPlayer == 1) {
            player.setSecondPlayer("AI");
                playWithAI(scanner, player, game);
        } else if (counterPlayer == 2) {
                playWithHuman(scanner, player, game);
        } else {
            System.out.println("Invalid option!");
        }
    }

    public static void chooseSymbol(char inputSymbol, Player player) {
        if (inputSymbol == 'X' || inputSymbol == 'x') {
            player.setFirstPlayerSymbol('X');
            player.setSecondPlayerSymbol('O');
        } else if (inputSymbol == 'O' || inputSymbol == 'o') {
            player.setFirstPlayerSymbol('O');
            player.setSecondPlayerSymbol('X');
        }
        else {
            System.out.println("Invalid option!");
        }
    }

    public static boolean firstChoice(Scanner scanner) {
        System.out.println("Would you like to play first, Y/N? ");
        String first_choice = scanner.next();

        if (first_choice.toUpperCase().equals("Y")) {
            return true;
        } else {
            return false;
        }
    }

    /*public static void firstTurn(Scanner scanner, Game game, Player player) {
        int cell;
        while (true) {
            System.out.println("Where would you like to play? (1-9)");
            cell = scanner.nextInt();
            if (checkEmptyCell(cell, game)){
                break;
            } else {
                System.out.println(cell + " is not a valid move.");
            }
        }
        setCell(game, player.getFirstPlayerSymbol(), cell);
    }*/

    public static void humanTurn(Scanner scanner, Game game, Player player, int playerNum) {
        int cell;
        while (true) {
            String playerName = "";
            if (playerNum == 1) {
                playerName = player.getFirstPlayer();
                /*System.out.println(playerName + ", where would you like to play? (1-9)");*/
            } else {
                playerName = player.getSecondPlayer();
            }

            System.out.println(playerName + ", where would you like to play? (1-9)");
            cell = scanner.nextInt();
            if (checkEmptyCell(cell, game)){
                break;
            } else {
                System.out.println(cell + " is not a valid move.");
            }
        }
        if (playerNum == 1) {
            setCell(game, player.getFirstPlayerSymbol(), cell);
        } else {
            setCell(game, player.getSecondPlayerSymbol(), cell);
        }
    }

    public static void AITurn(Game game, Player player) {
        Random random = new Random();
        int AICell;

        while (true) {
            AICell = random.nextInt(9) + 1;
            if (checkEmptyCell(AICell, game)) {
                break;
            }
        }
        System.out.println("AI will play cell " + AICell);
        setCell(game, player.getSecondPlayerSymbol(), AICell);
        //game.displayBoard();
    }

    public static boolean checkEmptyCell(int cell, Game game) {
        switch (cell) {
            case 1:
                return game.getCell(0, 0);
            case 2:
                return game.getCell(0, 1);
            case 3:
                return game.getCell(0, 2);
            case 4:
                return game.getCell(1, 0);
            case 5:
                return game.getCell(1, 1);
            case 6:
                return game.getCell(1, 2);
            case 7:
                return game.getCell(2, 0);
            case 8:
                return game.getCell(2, 1);
            case 9:
                return game.getCell(2, 2);
            default:
                return false;
        }
    }

    public static void setCell(Game game, char sym, int cell) {
        switch (cell) {
            case 1:
                game.mark(0, 0, sym);
                break;
            case 2:
                game.mark(0, 1, sym);
                break;
            case 3:
                game.mark(0, 2, sym);
                break;
            case 4:
                game.mark(1, 0, sym);
                break;
            case 5:
                game.mark(1, 1, sym);
                break;
            case 6:
                game.mark(1, 2, sym);
                break;
            case 7:
                game.mark(2, 0, sym);
                break;
            case 8:
                game.mark(2, 1, sym);
                break;
            case 9:
                game.mark(2, 2, sym);
                break;
        }
    }

    public static boolean checkWin(Game game, char symbol) {
        if (game.checkHorizontalWin(symbol) || game.checkVerticalWin(symbol) || game.checkDiagonalWin(symbol)) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean checkFinish(Game game, Player player) {
        if (checkWin(game, player.getFirstPlayerSymbol())) {
            game.displayBoard();
            System.out.println(player.getFirstPlayer() + " wins!!!");
            return true;
        }

        if (checkWin(game, player.getSecondPlayerSymbol())) {
            game.displayBoard();
            System.out.println(player.getSecondPlayer() + " wins!!!");
            return true;
        }

        if (game.checkEmptyCells()) {
            return false;
        }
        game.displayBoard();
        System.out.println("No winner. The game ends in a tie!");
        return true;
    }

    public static void weakAI(Scanner scanner, Player player, Game game) {
        String playerName = player.getFirstPlayer();

        System.out.println("Hello, " + playerName + " Choose your symbol, X or O: ");
        char symbol = scanner.next().charAt(0);
        chooseSymbol(symbol, player);

        if (firstChoice(scanner)) {
            while (true) {

                humanTurn(scanner, game, player, 1);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();

                AITurn(game, player);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
            }

        } else {
            while (true) {

                AITurn(game, player);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
                humanTurn(scanner, game, player, 1);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
            }
        }
    }

    public static void playWithAI(Scanner scanner, Player player, Game game) {
        // Choose difficulty level:
        System.out.println("Hello, Enter difficulty level: \n(1.) Weak AI\n(2.) Intelligent AI ");
        int difficultyLevel = scanner.nextInt();

        if (difficultyLevel == 1) {
            weakAI(scanner, player, game);
        } else if (difficultyLevel == 2) {
            //intelligentAI()
        }
    }

    public static void playWithHuman(Scanner scanner, Player player, Game game) {
        System.out.println("Second player, please enter your name: ");
        String secondPlayer = scanner.next();
        player.setSecondPlayer(secondPlayer);

        System.out.println("Hello, " + player.getFirstPlayer() + " Choose your symbol, X or O: ");
        char symbol = scanner.next().charAt(0);
        chooseSymbol(symbol, player);

        if (firstChoice(scanner)) {
            while (true) {

                humanTurn(scanner, game, player, 1);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();

                humanTurn(scanner, game, player, 2);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
            }

        } else {
            while (true) {

                humanTurn(scanner, game, player, 2);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
                humanTurn(scanner, game, player, 1);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
            }
        }
    }
    public static void main(String[] args) {
        mainMenu();
    }
}