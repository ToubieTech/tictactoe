import java.util.Random;
import java.util.Scanner;

public class Main {

    // Method to display the main menu:
    public static void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Travella TicTacToe!");

        // Instantiate an object of game class:
        Game game = new Game();

        // Instantiate an object of player class:
        Player player = new Player();

        // Prompt the primary player for name:
        System.out.println("Please enter your name: ");
        String firstPlayer = scanner.nextLine();

        // Store the player's name:
        if (firstPlayer.isEmpty()) {
            System.out.println("Name cannot be empty");
        } else {
            player.setFirstPlayer(firstPlayer);
        }

        // Choose to play between human or AI:
        System.out.println("Enter 1 to play against AI \nEnter 2 to play against human");
        int counterPlayer = scanner.nextInt();

        if (counterPlayer == 1) {
            player.setSecondPlayer("AI");
            playWithAI(scanner, player, game);
        } else if (counterPlayer == 2) {
            playWithHuman(scanner, player, game);
        } else {
            System.out.println("Invalid option!");
        }
    }

    // Method to choose symbol:
    public static void chooseSymbol(char inputSymbol, Player player) {
        if (inputSymbol == 'X' || inputSymbol == 'x') {
            player.setFirstPlayerSymbol('X');
            player.setSecondPlayerSymbol('O');
        } else if (inputSymbol == 'O' || inputSymbol == 'o') {
            player.setFirstPlayerSymbol('O');
            player.setSecondPlayerSymbol('X');
        }
        else {
            System.out.println("Invalid option!");
        }
    }

    // play with AI menu:

    public static void playWithAI(Scanner scanner, Player player, Game game) {
        // Choose difficulty level:
        System.out.println("Hello, " + player.getFirstPlayer() + ", enter difficulty level: \n(1.) Weak AI\n(2.) Intelligent AI ");
        int difficultyLevel = scanner.nextInt();

        if (difficultyLevel == 1) {
            weakAI(scanner, player, game);
        } else if (difficultyLevel == 2) {
            intelligentAI(scanner, player, game);
        } else {
            System.out.println("Invalid option!");
        }
    }

    // First choice method:
    public static boolean firstChoice(Scanner scanner) {
        System.out.println("Would you like to play first, Y/N? ");
        String first_choice = scanner.next();

        if (first_choice.equalsIgnoreCase("Y")) {
            return true;
        } else {
            return false;
        }
    }

    // Human Turn:
    public static void humanTurn(Scanner scanner, Game game, Player player, int playerNum) {
        int cell;
        while (true) {
            String playerName = "";
            if (playerNum == 1) {
                playerName += player.getFirstPlayer();
            } else {
                playerName += player.getSecondPlayer();
            }

            System.out.println(playerName + ", where would you like to play? (1-9)");
            cell = scanner.nextInt();

            if (checkEmptyCell(cell, game)){
                break;
            } else {
                System.out.println(cell + " is not a valid move.");
            }
        }
        if (playerNum == 1) {
            setCell(game, player.getFirstPlayerSymbol(), cell);
        } else {
            setCell(game, player.getSecondPlayerSymbol(), cell);
        }
    }

    // Weak AI turn:
    public static void AITurn(Game game, Player player) {
        Random random = new Random();
        int AICell;

        do {
            AICell = random.nextInt(9) + 1;
        } while (!checkEmptyCell(AICell, game));
        System.out.println("AI plays cell " + AICell);
        setCell(game, player.getSecondPlayerSymbol(), AICell);
    }


    // Intelligent AI turn:
    public static void intelTurn(Game game, Player player) {

        int AICell;

        do {
            AICell = getBestMoves(game, player);
        } while (!checkEmptyCell(AICell, game));
        System.out.println("AI plays cell " + AICell);
        setCell(game, player.getSecondPlayerSymbol(), AICell);
    }


    // Method to check whether the game has finished:
    public static boolean checkFinish(Game game, Player player) {
        if (checkWin(game, player.getFirstPlayerSymbol())) {
            game.displayBoard();
            System.out.println(player.getFirstPlayer() + " wins!!!");
            return true;
        }

        if (checkWin(game, player.getSecondPlayerSymbol())) {
            game.displayBoard();
            System.out.println(player.getSecondPlayer() + " wins!!!");
            return true;
        }

        if (game.checkEmptyCells()) {
            return false;
        }
        game.displayBoard();
        System.out.println("No winner. The game ends in a tie!");
        return true;
    }

    // Method to check winner:
    public static boolean checkWin(Game game, char symbol) {
        if (game.checkHorizontalWin(symbol) || game.checkVerticalWin(symbol) || game.checkDiagonalWin(symbol)) {
            return true;
        } else {
            return false;
        }
    }

    // Method to check empty cell:
    public static boolean checkEmptyCell(int cell, Game game) {
        switch (cell) {
            case 1:
                return game.isCellEmpty(0, 0);
            case 2:
                return game.isCellEmpty(0, 1);
            case 3:
                return game.isCellEmpty(0, 2);
            case 4:
                return game.isCellEmpty(1, 0);
            case 5:
                return game.isCellEmpty(1, 1);
            case 6:
                return game.isCellEmpty(1, 2);
            case 7:
                return game.isCellEmpty(2, 0);
            case 8:
                return game.isCellEmpty(2, 1);
            case 9:
                return game.isCellEmpty(2, 2);
            default:
                return false;
        }
    }

    // Method to set symbol to a cell:
    public static void setCell(Game game, char sym, int cell) {
        switch (cell) {
            case 1:
                game.setCell(0, 0, sym);
                break;
            case 2:
                game.setCell(0, 1, sym);
                break;
            case 3:
                game.setCell(0, 2, sym);
                break;
            case 4:
                game.setCell(1, 0, sym);
                break;
            case 5:
                game.setCell(1, 1, sym);
                break;
            case 6:
                game.setCell(1, 2, sym);
                break;
            case 7:
                game.setCell(2, 0, sym);
                break;
            case 8:
                game.setCell(2, 1, sym);
                break;
            case 9:
                game.setCell(2, 2, sym);
                break;
            default:
                System.out.println(":(");
        }
    }

    // weak AI method:
    public static void weakAI(Scanner scanner, Player player, Game game) {
        String playerName = player.getFirstPlayer();

        System.out.println("Hello, " + playerName + " Choose your symbol, X or O: ");
        char symbol = scanner.next().charAt(0);
        chooseSymbol(symbol, player);

        if (firstChoice(scanner)) {
            while (true) {

                humanTurn(scanner, game, player, 1);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();

                AITurn(game, player);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
            }

        } else {
            while (true) {

                AITurn(game, player);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
                humanTurn(scanner, game, player, 1);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
            }
        }
    }

    // Intelligent AI method:
    public static void intelligentAI(Scanner scanner, Player player, Game game) {
        String playerName = player.getFirstPlayer();

        System.out.println("Hello, " + playerName + " Choose your symbol, X or O: ");
        char symbol = scanner.next().charAt(0);
        chooseSymbol(symbol, player);

        if (firstChoice(scanner)) {
            while (true) {

                humanTurn(scanner, game, player, 1);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();

                intelTurn(game, player);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
            }

        } else {
            while (true) {

                intelTurn(game, player);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
                humanTurn(scanner, game, player, 1);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
            }
        }
    }

    // Play with human menu:
    public static void playWithHuman(Scanner scanner, Player player, Game game) {
        System.out.println("Second player, please enter your name: ");
        String secondPlayer = scanner.next();
        player.setSecondPlayer(secondPlayer);

        System.out.println("Hello, " + player.getFirstPlayer() + " Choose your symbol, X or O: ");
        char symbol = scanner.next().charAt(0);
        chooseSymbol(symbol, player);

        if (firstChoice(scanner)) {
            while (true) {

                humanTurn(scanner, game, player, 1);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();

                humanTurn(scanner, game, player, 2);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
            }

        } else {
            while (true) {

                humanTurn(scanner, game, player, 2);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
                humanTurn(scanner, game, player, 1);
                if (checkFinish(game, player)) {
                    break;
                }
                game.displayBoard();
            }
        }
    }

    // Minimax :

    // The game state to be implemented in the minimax algorithm:
    private static int gameState(Game game, Player player) {
        if (checkWin(game, player.getSecondPlayerSymbol())) {
            return 10;
        } else if (checkWin(game, player.getFirstPlayerSymbol())) {
            return -10;
        } else {
            return 0;
        }
    }


    // The minimax algorithm:
    private static int minimax(Game game, Player player, boolean isMaximizing, int depth) {
        // Use the game state to declare wins and draws between maximizing and minimizing players:
        int score = gameState(game, player);
        if (score == 10 || score == -10) {
            return score;
        }

        if (score == 0 && !game.checkEmptyCells()) {
            return 0;
        }

        int bestScore;
        if (isMaximizing) {
            bestScore = Integer.MIN_VALUE;

            // Loop through the number of available positions for players moves (1 - 9):
            for (int i = 1; i <= 9; i++) {
                // Set symbols to available cells to check and compare best moves using the minimax method recursively:
                if (checkEmptyCell(i, game)) {
                    setCell(game, player.getSecondPlayerSymbol(), i);
                    int scoreVal = minimax(game, player, false, depth + 1);
                    setCell(game, ' ', i);
                    bestScore = Math.max(bestScore, scoreVal);
                }
            }
        } else {
            bestScore = Integer.MAX_VALUE;

            for (int i = 1; i <= 9; i++) {
                if (checkEmptyCell(i, game)) {
                    setCell(game, player.getFirstPlayerSymbol(), i);
                    int scoreVal = minimax(game, player, true, depth + 1);
                    setCell(game,  ' ', i);
                    bestScore = Math.min(bestScore, scoreVal);
                }
            }

        }
        return bestScore;
    }

    public static int getBestMoves(Game game, Player player) {
        int bestScore = Integer.MIN_VALUE;
        int bestMove = -1;

        for (int i = 1; i <= 9; i++) {
            if (checkEmptyCell(i, game)) {
                setCell(game, player.getSecondPlayerSymbol(), i);
                int moves = minimax(game, player, false, 0);
                setCell(game,  ' ', i);

                if (moves > bestScore) {
                    bestMove = i;
                    bestScore = moves;
                }
            }
        }
        return bestMove;
    }

    // Execution:
    public static void main(String[] args) {
        displayMenu();
    }
}