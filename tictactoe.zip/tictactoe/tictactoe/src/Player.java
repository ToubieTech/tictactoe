public class Player {
    private String player_name;

    public Player(String player_name) {
        this.player_name = player_name;
    }

    public String getPlayer() {
        return player_name;
    }
}
