public class Player {
    // Data fields for the Game class:
    String[] players;
    char[] symbols;

    // The player class constructor:
    public Player() {
        // Initialize the players and symbols data field:
        players = new String[2];
        symbols = new char[2];
    }

    // Getters and Setters:
    public String getFirstPlayer() {return players[0];}

    public String getSecondPlayer() {return players[1];}

    public char getFirstPlayerSymbol() {return symbols[0];}

    public char getSecondPlayerSymbol() {return symbols[1];}

    public void setFirstPlayer(String firstPlayer) {players[0] = firstPlayer;}
    public void setSecondPlayer(String secondPlayer) {players[1] = secondPlayer;}
    public void setFirstPlayerSymbol(char firstPlayerSymbol) {symbols[0] = firstPlayerSymbol;}
    public void setSecondPlayerSymbol(char secondPlayerSymbol) {symbols[1] = secondPlayerSymbol;}
}
