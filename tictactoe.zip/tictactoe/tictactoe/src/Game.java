public class Game {
    // Data fields for the Game class:
    private char[][] board;

    // The game class constructor:
    public Game() {
        // Initialize the board data field and set it to a 2-dimensional 3 * 3 char array
        board = new char[3][3];
        startBoard();
    }

    public void startBoard() {
        // Loop through the first array:
        for (int i = 0; i < board.length; i++) {
            // Loop through the second array:
            for (int j = 0; j < board[i].length; j++) {
                board[i][j] = ' ';
            }
        }
    }

    public boolean getCell(int row, int column) {
        if (board[row][column] == ' ') {
            return true;
        } else {
            return false;
        }
    }

    public void displayBoard() {
        /*startBoard();*/
        System.out.println("-------------");
        // Loop through the first array:
        for (int i = 0; i < board.length; i++) {
            System.out.print("| ");
            // Loop through the second array:
            for (int j = 0; j < board[i].length; j++) {
                System.out.print(board[i][j] + " | ");
            }
            System.out.println();
            System.out.println("-------------");
        }
    }

    public void mark(int row, int column, char symbol) {
        board[row][column] = symbol;
    }

    public boolean checkHorizontalWin(char symbol) {
        for (int i = 0; i <= 2; i++) {
            if (board[i][0] == symbol && board[i][1] == symbol && board[i][2] == symbol) {
                return true;
            }
        }
        return false;
    }

    public boolean checkVerticalWin(char symbol) {
        for (int j = 0; j <= 2; j++) {
            if (board[0][j] == symbol  && board[1][j] == symbol &&  board[2][j] == symbol) {
                return true;
            }
        }
        return false;
    }

    public boolean checkDiagonalWin(char symbol) {
        if ((board[0][0] == symbol &&  board[1][1] == symbol && board[2][2] == symbol)|| (board[0][2] == symbol && board[1][1] == symbol && board[2][0] == symbol)) {
            return true;
        } else {
            return false;
        }
    }

    public boolean checkEmptyCells() {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                if (board[i][j] == ' ') {
                    return true;
                }
            }
        }
        return false;
    }
}
